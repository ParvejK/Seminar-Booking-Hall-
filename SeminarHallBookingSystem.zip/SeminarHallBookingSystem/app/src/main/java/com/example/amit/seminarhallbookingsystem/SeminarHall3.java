package com.example.amit.seminarhallbookingsystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SeminarHall3 extends AppCompatActivity {
    String str_user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seminar_hall3);
        str_user = getIntent().getStringExtra("user");
    }
    public void book(View view){
        Intent intent = new Intent(SeminarHall3.this, Book.class);
        intent.putExtra("hall","Bhaskara Hall");
        intent.putExtra("user", str_user);
        startActivity(intent);
    }
}