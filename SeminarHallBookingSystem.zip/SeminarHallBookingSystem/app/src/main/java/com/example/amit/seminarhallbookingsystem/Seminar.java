package com.example.amit.seminarhallbookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class Seminar extends AppCompatActivity {
    String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seminar);
        user = getIntent().getStringExtra("user");
    }
    public void logout(View view){
        Intent intent = new Intent(Seminar.this, MainActivity.class);
        startActivity(intent);
    }
    public void sh1(View view){
        Intent intent = new Intent(Seminar.this, SeminarHall1.class);
        intent.putExtra("user", user);
        startActivity(intent);
    }
    public void sh2(View view){
        Intent intent = new Intent(Seminar.this, SeminarHall2.class);
        intent.putExtra("user", user);
        startActivity(intent);
    }
    public void sh3(View view){
        Intent intent = new Intent(Seminar.this, SeminarHall3.class);
        intent.putExtra("user", user);
        startActivity(intent);
    }
    public void sh4(View view){
        Intent intent = new Intent(Seminar.this, SeminarHall4.class);
        intent.putExtra("user", user);
        startActivity(intent);
    }
    public void show_booking(View view){
        Intent intent = new Intent(Seminar.this, Show_My_Booking.class);
        intent.putExtra("user", user);
        startActivity(intent);
    }
    public void cancel(View view){
        Intent intent = new Intent(Seminar.this, Cancel.class);
        intent.putExtra("user", user);
        startActivity(intent);
    }
}