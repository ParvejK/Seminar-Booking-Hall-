package com.example.amit.seminarhallbookingsystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SeminarHall1 extends AppCompatActivity {
    String str_user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seminar_hall1);
        str_user = getIntent().getStringExtra("user");
    }
    public void book(View view){
        Intent intent = new Intent(SeminarHall1.this, Book.class);
        intent.putExtra("hall","Aryabhatta Hall");
        intent.putExtra("user", str_user);
        startActivity(intent);
    }
}