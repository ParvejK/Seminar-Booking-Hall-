package com.example.amit.seminarhallbookingsystem;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Show_My_Booking extends AppCompatActivity {
    String user;
    TableLayout table;
    TextView textView,textView2;
    JSONArray jsonArray;
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<HashMap<String, String>>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        table = (TableLayout) findViewById(R.id.table);
        textView = (TextView) findViewById(R.id.textView);
        textView2= (TextView) findViewById(R.id.textView2);
        textView2.setText("YOUR BOOKINGS...");
        user = getIntent().getStringExtra("user");
        new BackgroundWork().execute(user);
    }

    public class BackgroundWork extends AsyncTask<String, Void, String> {
        String username;

        @Override
        protected String doInBackground(String... params) {
            username = params[0];
            String show2_url = "http://andromeda.nitc.ac.in/~m130299ca/seminar/show2.php?user="+username;
            JSONParser jsonParser = new JSONParser();
            JSONObject js = jsonParser.makeHttpRequest(show2_url, "GET");
            try {
                jsonArray = js.getJSONArray("server_response");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String hall_name = jsonObject.get("hall_name").toString();
                    String date = jsonObject.get("date").toString();
                    String time = jsonObject.get("time").toString();
                    String sub = jsonObject.get("sub").toString();
                    HashMap<String, String> singleEntry = new HashMap<String, String>();
                    singleEntry.put("hall_name", hall_name);
                    singleEntry.put("date", date);
                    singleEntry.put("time", time);
                    singleEntry.put("sub", sub);
                    arrayList.add(singleEntry);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            for(int i=0;i<=arrayList.size();i++){
                TableRow row = new TableRow(Show_My_Booking.this);
                row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                for (int j = 1; j <= 4; j++) {
                    TextView tv = new TextView(Show_My_Booking.this);
                    tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                    tv.setPadding(20,20,20,20);
                    if(i==0){
                        if(j==1)
                            tv.setText(Html.fromHtml("<b>Date</b>"));
                        else if(j==2)
                            tv.setText(Html.fromHtml("<b>Time</b>"));
                        else if(j==3)
                            tv.setText(Html.fromHtml("<b>Hall</b>"));
                        else
                            tv.setText(Html.fromHtml("<b>Subject</b>"));
                    }
                    else {
                        if(j==1)
                            tv.setText(arrayList.get(i - 1).get("date"));
                        else if(j==2)
                            tv.setText(arrayList.get(i - 1).get("time"));
                        else if(j==3)
                            tv.setText(arrayList.get(i - 1).get("hall_name"));
                        else
                            tv.setText(arrayList.get(i - 1).get("sub"));
                    }
                    row.addView(tv);
                }
                table.addView(row);
            }
        }
    }
}