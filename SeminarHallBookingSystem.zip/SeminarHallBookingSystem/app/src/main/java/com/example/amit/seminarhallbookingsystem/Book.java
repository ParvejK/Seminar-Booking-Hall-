package com.example.amit.seminarhallbookingsystem;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Book extends Activity implements AdapterView.OnItemSelectedListener {
    TextView hall;
    EditText etdate, etsub;
    String str_hall,str_time,str_date,str_username,str_sub;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);
        hall = (TextView) findViewById(R.id.hall);
        etdate = (EditText) findViewById(R.id.date);
        etsub = (EditText) findViewById(R.id.sub);
        str_username = getIntent().getStringExtra("user");
        str_hall = getIntent().getStringExtra("hall");
        hall.setText(str_hall);
        // Spinner element
        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        // Spinner click listener
        spinner.setOnItemSelectedListener(this);

        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("08:00 AM - 09:00 AM");
        categories.add("09:00 AM - 10:00 AM");
        categories.add("10:00 AM - 11:00 AM");
        categories.add("11:00 AM - 12:00 PM");
        categories.add("12:00 PM - 01:00 PM");
        categories.add("02:00 PM - 03:00 PM");
        categories.add("03:00 PM - 04:00 PM");
        categories.add("04:00 PM - 05:00 PM");
        categories.add("05:00 PM - 06:00 PM");
        categories.add("06:00 PM - 07:00 PM");

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        str_time = parent.getItemAtPosition(position).toString();

        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "Selected: " + str_time, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    public void logout(View view){
        Intent intent = new Intent(Book.this, MainActivity.class);
        startActivity(intent);
    }
    public void book(View view){
        Date cdate=null, sdate=null;
        String cur_date;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        cur_date = sdf.format(date);
        str_date = etdate.getText().toString();
        str_sub = etsub.getText().toString();
        try {
            cdate = sdf.parse(cur_date);
            sdate = sdf.parse(str_date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        DateValidator dateValidator = new DateValidator();
        if(str_date.equals("")){
            Toast.makeText(Book.this,"Date can't be left blank",Toast.LENGTH_SHORT).show();
        }
        else if(!dateValidator.validate(str_date)){
            Toast.makeText(Book.this,"invalid date",Toast.LENGTH_SHORT).show();
        }
        else if(sdate.compareTo(cdate)<0){
            Toast.makeText(Book.this,"Can't be book hall before today's date.",Toast.LENGTH_SHORT).show();
        }
        else if(str_sub.equals("")){
            Toast.makeText(Book.this,"Sub/Topic can't be left blank",Toast.LENGTH_SHORT).show();
        }
        else {
            BackgroundWorker backgroundWorker = new BackgroundWorker(this);
            backgroundWorker.execute(str_hall, str_date, str_time, str_username, str_sub);
        }
    }
    public void cancel(View view){
        Intent intent = new Intent(Book.this, Seminar.class);
        intent.putExtra("user", str_username);
        startActivity(intent);
    }
    public class BackgroundWorker extends AsyncTask<String,Void,String> {
        Context context;
        BackgroundWorker(Context ctx){
            context = ctx;
        }
        @Override
        protected String doInBackground(String... params) {
            String register_url = "http://andromeda.nitc.ac.in/~m130299ca/seminar/book.php";
            try {
                String hall = params[0];
                String date = params[1];
                String time = params[2];
                String username = params[3];
                String sub = params[4];
                URL url = new URL(register_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("date", "UTF-8")+"="+URLEncoder.encode(date,"UTF-8")+"&"+
                        URLEncoder.encode("time","UTF-8")+"="+URLEncoder.encode(time,"UTF-8")+"&"+
                        URLEncoder.encode("username","UTF-8")+"="+ URLEncoder.encode(username, "UTF-8")+"&"+
                        URLEncoder.encode("hall","UTF-8")+"="+ URLEncoder.encode(hall, "UTF-8")+"&"+
                        URLEncoder.encode("sub","UTF-8")+"="+ URLEncoder.encode(sub, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while ((line = bufferedReader.readLine()) != null){
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if(result.equals("1")) {
            Toast.makeText(Book.this, "You have booked successfully !", Toast.LENGTH_LONG).show();
            }
            if(result.equals("0")) {
                Toast.makeText(Book.this, "Hall already booked on this date and time !", Toast.LENGTH_LONG).show();
            }
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }
}